<?php
		require("../Model/Show-Appointment-model.php");
?>

<?php


if(isset($_GET['q'])){
$data = doc_authentication($_GET['q']);

if($data != null){?>

<table>
  
    <tr>

    <th>Doctor's Name</th>

    <th>Date</th>

    <th>Time</th>

</tr>

<tr>

    <td><?php echo $data["doctor_name"] ; ?></td>

    <td><?php echo $data["date"] ; ?></td>

    <td><?php echo $data["time"] ; ?></td>


</tr>
</table>
 
<?php
}else{
  echo $_GET['q']." does not exist";
}



}

?>