<?php require("head.php"); ?>
<?php 
    if(!isset($_SESSION["username"])){
        header("location: Login.php");
    }

?>

<div class="container custom-form-dashboard">
	<div class="navitems">
		<table style="width: 100%;">
			 <tr style="width: 100%;">

              <td style="width: 20%;">
			   <ul id="list-of-url">

			   		<li style="padding: 150px;">User Account</li>
			   		<hr>
                    <li><a href="../View/Dasboard.php"><b style="color:green;">Dashboard</b></a></li>
                    <li><a href="../View/View Profile.php">View Profile</a></li>
                    <li><a href="../View/Edit Profile.php">Edit Profile</a></li>
                    <li><a href="../View/Change Profile Picture.php">Change Profile Picture</a></li>
                    <li><a href="../View/Change Password.php">Change Password</a></li>
              
                    <li><a href="../View/Show-Appointment.php">Show Appointment</a></li>
                    <li><a href="../View/Prescription.php">Prescription</a></li>
                                    </ul>
               </td>
               <td style="width: 70%;">
               	<h1>
               	<?php
					if(!isset($_COOKIE['username'])){
                echo "Cookie is not set";
            }else{
                echo "Welcome ".$_COOKIE['username'];}

				    

				?></h1>
               </td>
             </tr>
            
		</table>            
    </div>
</div>
<?php require("foot.php"); ?>