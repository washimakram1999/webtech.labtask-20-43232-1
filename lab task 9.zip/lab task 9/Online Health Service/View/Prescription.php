<?php require("head.php"); 
require("../Controller/Prescription-control.php"); 
if(!isset($_SESSION["username"])){
        header("location: Login.php");
    }
?>

<div class="container custom-form-dashboard">
  <div class="navitems">
    <table style="width: 100%;">
       <tr style="width: 100%;">

              <td style="width: 20%;">
         <ul id="list-of-url">

            <li style="padding: 180px;">User Account</li>
            <hr>
                    <li><a href="../View/Dasboard.php">Dashboard</a></li>
                    <li><a href="../View/View Profile.php">View Profile</a></li>
                    <li><a href="../View/Edit Profile.php">Edit Profile</a></li>
                    <li><a href="../View/Change Profile Picture.php">Change Profile Picture</a></li>
                    <li><a href="../View/Change Password.php">Change Password</a></li>
                   
                    <li><a href="../View/Show-Appointment.php">Show Appointment</a></li>
                    <li><a href="../View/Prescription.php"><b style="color:green;">Prescription</b></a></li>
                   
                </ul>
               </td>
               <td style="width: 70%;">
                
               <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post" enctype="multipart/form-data">
                  <br>
                  <h1>Prescription: </h1><br>
                  <h3>Uplod here: <input type="file" name="pfile"></h3><br><br>
                  <input type="submit" name="sub" value="Submit">
                  <br>
                </form>
               </td>
             </tr>
            
    </table>            
    </div>
</div>


<?php include("foot.php"); ?>