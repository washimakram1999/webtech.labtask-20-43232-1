<?php 

require("db_connect.php");

function doc_authentication($doctor_name){
    $conn = db_conn();
    $selectQuery =  "SELECT * FROM `patient` WHERE `patient_name`= ?;"; 
 
    try{
        $stmt = $conn->prepare($selectQuery);
        $stmt->execute([$doctor_name]); 
    }catch(PDOException $e){
        echo $e->getMessage();
    }
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row;
}


?>